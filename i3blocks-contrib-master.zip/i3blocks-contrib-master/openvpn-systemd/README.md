# openvpn-systemd

Show connection status of VPNs managed by systemd.

![](openvpn-systemd.png)

# Config

```ini
[openvpn-systemd]
command=$SCRIPT_DIR/openvpn-systemd
interval=20
label=VPN 
```
