# battery

Show battery info.

![](battery.png)

# Dependencies

* `acpi`

# Config

```
[battery]
command=$SCRIPT_DIR/battery
interval=30
LABEL=BAT
#LABEL=⚡
#BAT_NUMBER=0
```
